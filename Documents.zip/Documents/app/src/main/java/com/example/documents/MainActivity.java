package com.example.documents;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView expirydate;
    DatePickerDialog.OnDateSetListener setListener;
    private EditText productName;
    private Button addProduct;
    private int expiry_data_set=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expirydate=findViewById(R.id.expiry_date);
        java.util.Calendar calender= java.util.Calendar.getInstance();
        final int year = calender.get(Calendar.YEAR);
        final int month = calender.get(Calendar.MONTH);
        final int day = calender.get(Calendar.DAY_OF_MONTH);

        expirydate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        MainActivity.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,setListener,year,month,day
                );
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis()-1000);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });
        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int DayofMonth) {
                month=month+1;
                String date= day+"/"+month+"/"+year;
                expirydate.setText(date);
                expiry_data_set=1;
            }
        };
        productName = findViewById(R.id.Product_Name);
        addProduct=findViewById(R.id.button);

        productName.addTextChangedListener(loginTextWatcher);
        expirydate.addTextChangedListener(loginTextWatcher);

    }
    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String product=productName.getText().toString().trim();
            String expiry=expirydate.getText().toString().trim();
            addProduct.setEnabled(!product.isEmpty() && expiry_data_set==1);
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
}
